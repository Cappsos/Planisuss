# Planisuss
 A simple life simulations plotted on matplotlib.

## User control 
The user can pause the simulation by using the space bar. when paused the user can decide to salve the simulation os to stop it. 

The user can also click on any cell of the world grid to plot its population trend

## Plotting saved data

When starting the main script at the user is asked if they want to start a new simulation or to load an old one. 

If the user instead want to plot the data of the previously runned simulation they can run the event_logger module to plot those informations

If the user wants to save a particular simulation they are invited at saving the contents of the folder "logs_and_saves". This folder contains all the necessary information to recover the simulation. Do not delete the folder while doing so, this will cause the program to crash. 
 
